﻿using _25102022_Capella_MaskeliBeşler.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25102022_Capella_MaskeliBeşler
{
    public partial class frmAnasayfa : Form  // This project was created by ByCrystal02.
    {
        public frmAnasayfa()
        {
            InitializeComponent();
        }
         
        frmMediaPlayer frmMP = new frmMediaPlayer();
        public PictureBox pcrAfis1 = new PictureBox();
        CapellaContext db = new CapellaContext();
        Film film = new Film();
        int filmSayisi = 0;

        #region Form Load
        private void frmAnasayfa_Load(object sender, EventArgs e)
        {
            filmSayisi = db.Film.Select(x => new { x.FilmID }).Count();            
            Program.button = new Button[filmSayisi];
            Program.pcr = new PictureBox[filmSayisi];
            filmSayilari = new string[filmSayisi];
            diziOyuncular = new string[filmSayisi];
            pcrSayi = new string[filmSayisi];
            butonSayi = new string[filmSayisi];
            Program.filmYolu = new string[filmSayisi];
            
            //FilmDoldur(12);


            var kategori = db.FilmTur.ToList();
            cmbKategori.DataSource = kategori;
            cmbKategori.DisplayMember = "ad";
            cmbKategori.ValueMember = "filmTurID";

            cmbKategori.BackColor = Color.FromArgb(81, 36, 36);
            txtArama.BackColor = Color.FromArgb(81, 36, 36);
            pcrAra.BackColor = Color.FromArgb(81, 36, 36);
            txtArama.Text = "Film Ara...";
            
        }
        #endregion

        #region The Process Of Shooting Films
        public void mainFilm() // Fimleri çekme alanı.
        {
            int artis = 0;
            int butonSayisi = 0;
            int pictureBoxSayisi = 0;
            //int labelSayisi = 0;
            flwlytpnlResim.Controls.Clear();
            var filmTurID = ((FilmTur)cmbKategori.SelectedItem).filmTurID;
            var filmler = db.Film.Where(x => x.filmTurId == filmTurID).ToList();
            int[] filmID = new int[filmler.Count];
            foreach (var film in filmler)
            {
                #region GroupBox Oluşturma ve Özelliklerini Değiştirme
                GroupBox resim = new GroupBox();
                resim.Width = 332;
                resim.Height = 469;
                resim.Margin = new Padding(5);
                resim.Text = film.ad;
                resim.Margin = new Padding(30, 10, 10, 30);
                resim.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                resim.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                resim.BackColor = Color.Black;
                #endregion

                #region PictureBox Oluşturma ve Özelliklerini Değiştirme
                PictureBox pcrAfis = new PictureBox();
                pcrSayi[pictureBoxSayisi] = "Afis" + pictureBoxSayisi;
                pcrAfis.Name = pcrSayi[pictureBoxSayisi];
                pcrAfis.Width = 160;
                pcrAfis.Height = 255;
                pcrAfis.SizeMode = PictureBoxSizeMode.StretchImage;
                pcrAfis.ImageLocation = film.afis;
                pcrAfis.Location = new Point(13, 32);
                filmSayilari[artis] = pcrAfis.ImageLocation;
                artis++;
                Program.pcr[pictureBoxSayisi] = pcrAfis;
                pictureBoxSayisi++;

                #endregion

                #region  Label Oluşturma ve Özelliklerini Değiştirme

                Label lblBaslik = new Label();
                lblBaslik.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblBaslik.Text = "Başrol";
                lblBaslik.Location = new Point(174, 38);
                lblBaslik.Size = new System.Drawing.Size(139, 34);
                lblBaslik.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);
                lblBaslik.BackColor = Color.Transparent;
                #endregion

                #region Foreach İle Labelları Veri Tabanından Çekme İşlemi
                var oyuncular = film.oyuncu.Split(',');

                int[] konum = { 80, 120, 160 };
                int x = 0;
                int[] konumy = { 175, 175, 175 };
                int y = 0;
                foreach (var oyuncu in oyuncular)
                {

                    Label l1 = new Label();
                    l1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                    l1.Size = new System.Drawing.Size(500, 30);
                    l1.Location = new Point(konumy[y], konum[x]);
                    l1.Text = oyuncu;
                    l1.BackColor = Color.Transparent;
                    l1.Font = new Font("Comic Sans MS", 14, FontStyle.Regular);
                    x++;

                    resim.Controls.Add(l1);
                }
                #endregion

                #region Label Puan Oluşturma Ve Özelleştirme
                Label lblIMDB = new Label();
                lblIMDB.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblIMDB.Text = "IMDB";
                lblIMDB.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                lblIMDB.Location = new Point(175, 200);
                lblIMDB.Size = new System.Drawing.Size(137, 34);
                lblIMDB.BackColor = Color.Transparent;

                Label lblIMDBp = new Label();
                lblIMDBp.Location = new Point(175, 230);
                lblIMDBp.Text = film.puan.ToString();
                lblIMDBp.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblIMDBp.Size = new System.Drawing.Size(155, 34);
                lblIMDBp.BackColor = Color.Transparent;
                lblIMDBp.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);


                #endregion

                #region Label Açıklama Ve Oluşturma Özelleştirme
                Label lblAciklama = new Label();
                lblAciklama.Font = new Font("Comic Sans MS", 12, FontStyle.Regular);
                lblAciklama.Text = film.aciklama;
                lblAciklama.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblAciklama.BackColor = Color.Transparent;
                lblAciklama.Location = new Point(10, 288);
                lblAciklama.Size = new System.Drawing.Size(320, 120);
                #endregion

                #region Buton Oluşturma ve Özelliklerini Değiştirme
                Button btnIzle = new Button();

                butonSayi[butonSayisi] = "Buton" + butonSayisi;
                btnIzle.Name = butonSayi[butonSayisi];

                btnIzle.Text = "İzle";
                btnIzle.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                btnIzle.BackColor = Color.Black;
                btnIzle.FlatStyle = FlatStyle.Flat;
                btnIzle.Location = new Point(20, 390);
                btnIzle.Width = 293;
                btnIzle.Height = 69;
                btnIzle.Cursor = Cursors.Hand;
                btnIzle.Font = new Font(btnIzle.Font.FontFamily, 20);

                Program.filmYolu[butonSayisi] = film.filmDosyaYolu;
                //btnIzle.Name = film.filmDosyaYolu;

                btnIzle.Click += BtnIzle_Click;



                Program.button[butonSayisi] = btnIzle;
                butonSayisi++;
                #endregion

                #region Oluşturulan Tool'ları Forma Ekleme

                flwlytpnlResim.Controls.Add(resim);
                resim.Controls.Add(pcrAfis);
                resim.Controls.Add(lblBaslik);
                resim.Controls.Add(btnIzle);
                resim.Controls.Add(lblAciklama);
                resim.Controls.Add(lblIMDB);
                resim.Controls.Add(lblIMDBp);

                #endregion
            }
        }
        public void mainDizi() // Dizileri çekme alanı.
        {
            int artis = 0;
            int butonSayisi = 0;
            int pictureBoxSayisi = 0;
            //int labelSayisi = 0;

            flwlytpnlResim.Controls.Clear();
            var filmTurID = ((FilmTur)cmbKategori.SelectedItem).filmTurID;
            var filmler = db.Film.Where(x => x.filmTurId == filmTurID).ToList();
            int[] filmID = new int[filmler.Count];
            foreach (var film in filmler)
            {
                #region GroupBox Oluşturma ve Özelliklerini Değiştirme
                GroupBox resim = new GroupBox();
                resim.Width = 332;
                resim.Height = 469;
                resim.Margin = new Padding(5);
                resim.Text = film.ad;
                resim.Margin = new Padding(30, 10, 10, 30);
                resim.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                resim.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                resim.BackColor = Color.Black;
                #endregion

                #region PictureBox Oluşturma ve Özelliklerini Değiştirme
                PictureBox pcrAfis = new PictureBox();
                pcrSayi[pictureBoxSayisi] = "Afis" + pictureBoxSayisi;
                pcrAfis.Name = pcrSayi[pictureBoxSayisi];
                pcrAfis.Width = 160;
                pcrAfis.Height = 255;
                pcrAfis.SizeMode = PictureBoxSizeMode.StretchImage;
                pcrAfis.ImageLocation = film.afis;
                pcrAfis.Location = new Point(13, 32);
                filmSayilari[artis] = pcrAfis.ImageLocation;
                artis++;
                Program.pcr[pictureBoxSayisi] = pcrAfis;
                pictureBoxSayisi++;

                #endregion

                #region  Label Oluşturma ve Özelliklerini Değiştirme

                Label lblBaslik = new Label();
                lblBaslik.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblBaslik.Text = "Başrol";
                lblBaslik.Location = new Point(174, 38);
                lblBaslik.Size = new System.Drawing.Size(139, 34);
                lblBaslik.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);
                lblBaslik.BackColor = Color.Transparent;
                #endregion

                #region Foreach İle Labelları Veri Tabanından Çekme İşlemi
                var oyuncular = film.oyuncu.Split(',');

                int[] konum = { 80, 120, 160 };
                int x = 0;
                int[] konumy = { 175, 175, 175 };
                int y = 0;
                foreach (var oyuncu in oyuncular)
                {

                    Label l1 = new Label();
                    l1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                    l1.Size = new System.Drawing.Size(500, 30);
                    l1.Location = new Point(konumy[y], konum[x]);
                    l1.Text = oyuncu;
                    l1.BackColor = Color.Transparent;
                    l1.Font = new Font("Comic Sans MS", 14, FontStyle.Regular);
                    x++;

                    resim.Controls.Add(l1);
                }
                #endregion

                #region Label Puan Oluşturma Ve Özelleştirme
                Label lblIMDB = new Label();
                lblIMDB.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblIMDB.Text = "IMDB";
                lblIMDB.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                lblIMDB.Location = new Point(175, 200);
                lblIMDB.Size = new System.Drawing.Size(137, 34);
                lblIMDB.BackColor = Color.Transparent;

                Label lblIMDBp = new Label();
                lblIMDBp.Location = new Point(175, 230);
                lblIMDBp.Text = film.puan.ToString();
                lblIMDBp.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblIMDBp.Size = new System.Drawing.Size(155, 34);
                lblIMDBp.BackColor = Color.Transparent;
                lblIMDBp.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);


                #endregion

                #region Label Açıklama Ve Oluşturma Özelleştirme
                Label lblAciklama = new Label();
                lblAciklama.Font = new Font("Comic Sans MS", 12, FontStyle.Regular);
                lblAciklama.Text = film.aciklama;
                lblAciklama.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblAciklama.BackColor = Color.Transparent;
                lblAciklama.Location = new Point(10, 288);
                lblAciklama.Size = new System.Drawing.Size(320, 120);
                #endregion

                #region Buton Oluşturma ve Özelliklerini Değiştirme
                Button btnIzle = new Button();

                butonSayi[butonSayisi] = "Buton" + butonSayisi;
                btnIzle.Name = butonSayi[butonSayisi];

                btnIzle.Text = "İzle";
                btnIzle.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                btnIzle.BackColor = Color.Black;
                btnIzle.FlatStyle = FlatStyle.Flat;
                btnIzle.Location = new Point(20, 390);
                btnIzle.Width = 293;
                btnIzle.Height = 69;
                btnIzle.Cursor = Cursors.Hand;
                btnIzle.Font = new Font(btnIzle.Font.FontFamily, 20);

                Program.filmYolu[butonSayisi] = film.filmDosyaYolu;
                //btnIzle.Name = film.filmDosyaYolu;

                btnIzle.Click += BtnIzle_Click;


                Program.button[butonSayisi] = btnIzle;
                butonSayisi++;
                #endregion

                #region Oluşturulan Tool'ları Forma Ekleme

                flwlytpnlResim.Controls.Add(resim);
                resim.Controls.Add(pcrAfis);
                resim.Controls.Add(lblBaslik);
                resim.Controls.Add(btnIzle);
                resim.Controls.Add(lblAciklama);
                resim.Controls.Add(lblIMDB);
                resim.Controls.Add(lblIMDBp);

                #endregion
            }
        }
        public void mainAnime() // Animeleri çekme alanı.
        {
            int artis = 0;
            int butonSayisi = 0;
            int pictureBoxSayisi = 0;
            //int labelSayisi = 0;

            flwlytpnlResim.Controls.Clear();
            var filmTurID = ((FilmTur)cmbKategori.SelectedItem).filmTurID;
            var filmler = db.Film.Where(x => x.filmTurId == filmTurID).ToList();
            int[] filmID = new int[filmler.Count];
            foreach (var film in filmler)
            {
                #region GroupBox Oluşturma ve Özelliklerini Değiştirme
                GroupBox resim = new GroupBox();
                resim.Width = 332;
                resim.Height = 469;
                resim.Margin = new Padding(5);
                resim.Text = film.ad;
                resim.Margin = new Padding(30, 10, 10, 30);
                resim.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                resim.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                resim.BackColor = Color.Black;
                #endregion

                #region PictureBox Oluşturma ve Özelliklerini Değiştirme
                PictureBox pcrAfis = new PictureBox();
                pcrSayi[pictureBoxSayisi] = "Afis" + pictureBoxSayisi;
                pcrAfis.Name = pcrSayi[pictureBoxSayisi];
                pcrAfis.Width = 160;
                pcrAfis.Height = 255;
                pcrAfis.SizeMode = PictureBoxSizeMode.StretchImage;
                pcrAfis.ImageLocation = film.afis;
                pcrAfis.Location = new Point(13, 32);
                filmSayilari[artis] = pcrAfis.ImageLocation;
                artis++;
                Program.pcr[pictureBoxSayisi] = pcrAfis;
                pictureBoxSayisi++;

                #endregion

                #region  Label Oluşturma ve Özelliklerini Değiştirme

                Label lblBaslik = new Label();
                lblBaslik.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblBaslik.Text = "Başrol";
                lblBaslik.Location = new Point(174, 38);
                lblBaslik.Size = new System.Drawing.Size(139, 34);
                lblBaslik.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);
                lblBaslik.BackColor = Color.Transparent;
                #endregion

                #region Foreach İle Labelları Veri Tabanından Çekme İşlemi
                var oyuncular = film.oyuncu.Split(',');

                int[] konum = { 80, 120, 160 };
                int x = 0;
                int[] konumy = { 175, 175, 175 };
                int y = 0;
                foreach (var oyuncu in oyuncular)
                {

                    Label l1 = new Label();
                    l1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                    l1.Size = new System.Drawing.Size(500, 30);
                    l1.Location = new Point(konumy[y], konum[x]);
                    l1.Text = oyuncu;
                    l1.BackColor = Color.Transparent;
                    l1.Font = new Font("Comic Sans MS", 14, FontStyle.Regular);
                    x++;

                    resim.Controls.Add(l1);
                }
                #endregion

                #region Label Puan Oluşturma Ve Özelleştirme
                Label lblIMDB = new Label();
                lblIMDB.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblIMDB.Text = "IMDB";
                lblIMDB.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                lblIMDB.Location = new Point(175, 200);
                lblIMDB.Size = new System.Drawing.Size(137, 34);
                lblIMDB.BackColor = Color.Transparent;

                Label lblIMDBp = new Label();
                lblIMDBp.Location = new Point(175, 230);
                lblIMDBp.Text = film.puan.ToString();
                lblIMDBp.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblIMDBp.Size = new System.Drawing.Size(155, 34);
                lblIMDBp.BackColor = Color.Transparent;
                lblIMDBp.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);


                #endregion

                #region Label Açıklama Ve Oluşturma Özelleştirme
                Label lblAciklama = new Label();
                lblAciklama.Font = new Font("Comic Sans MS", 12, FontStyle.Regular);
                lblAciklama.Text = film.aciklama;
                lblAciklama.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblAciklama.BackColor = Color.Transparent;
                lblAciklama.Location = new Point(10, 288);
                lblAciklama.Size = new System.Drawing.Size(320, 120);
                #endregion

                #region Buton Oluşturma ve Özelliklerini Değiştirme
                Button btnIzle = new Button();

                butonSayi[butonSayisi] = "Buton" + butonSayisi;
                btnIzle.Name = butonSayi[butonSayisi];

                btnIzle.Text = "İzle";
                btnIzle.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                btnIzle.BackColor = Color.Black;
                btnIzle.FlatStyle = FlatStyle.Flat;
                btnIzle.Location = new Point(20, 390);
                btnIzle.Width = 293;
                btnIzle.Height = 69;
                btnIzle.Cursor = Cursors.Hand;
                btnIzle.Font = new Font(btnIzle.Font.FontFamily, 20);
                Program.filmYolu[butonSayisi] = film.filmDosyaYolu;
                //btnIzle.Name = film.filmDosyaYolu;

                btnIzle.Click += BtnIzle_Click;


                Program.button[butonSayisi] = btnIzle;
                butonSayisi++;
                #endregion

                #region Oluşturulan Tool'ları Forma Ekleme

                flwlytpnlResim.Controls.Add(resim);
                resim.Controls.Add(pcrAfis);
                resim.Controls.Add(lblBaslik);
                resim.Controls.Add(btnIzle);
                resim.Controls.Add(lblAciklama);
                resim.Controls.Add(lblIMDB);
                resim.Controls.Add(lblIMDBp);

                #endregion
            }
        }
        #endregion

        #region Creating Of Arrays
        string[] afis = new string[15];
        string[] pcrSayi = new string[0];

        string[] butonSayi = new string[0];
        string[] filmSayilari = new string[0];
        string[] diziOyuncular = new string[0];
        #endregion       

        #region The Movie Search Process
        string arama;
        private void txtArama_KeyDown(object sender, KeyEventArgs e)
        {
            
            if(e.KeyCode == Keys.Enter)
            {
                int butonSayisi = 0;
                arama = txtArama.Text;
                var film = db.Film.Where(x => x.ad == arama).ToList();
                if (film.Count == 0)
                {
                    MessageBox.Show("Aradığınız isimde bir film bulunmamaktadır. Lütfen tekrar deneyiniz.", "Hata!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    frmAnasayfa frm = new frmAnasayfa();
                    frm.Refresh();
                }
                else
                {
                    flwlytpnlResim.Controls.Clear();
                }

                foreach (var secilenFilm in film)
                {
                    #region GroupBox Oluşturma ve Özelliklerini Değiştirme
                    GroupBox resim = new GroupBox();
                    resim.Width = 332;
                    resim.Height = 469;
                    resim.Margin = new Padding(5);
                    resim.Text = secilenFilm.ad;
                    resim.Margin = new Padding(30, 10, 10, 30);
                    resim.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                    resim.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                    #endregion

                    #region PictureBox Oluşturma ve Özelliklerini Değiştirme
                    PictureBox pcrAfis = new PictureBox();
                    pcrAfis.Width = 160;
                    pcrAfis.Height = 255;
                    pcrAfis.SizeMode = PictureBoxSizeMode.StretchImage;
                    pcrAfis.ImageLocation = secilenFilm.afis;
                    pcrAfis.Location = new Point(13, 32);
                    #endregion

                    #region  Label Oluşturma ve Özelliklerini Değiştirme

                    Label lblBaslik = new Label();
                    lblBaslik.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                    lblBaslik.Text = "Oyuncular";
                    lblBaslik.Location = new Point(174, 38);
                    lblBaslik.Size = new System.Drawing.Size(139, 34);
                    lblBaslik.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);
                    lblBaslik.BackColor = Color.Transparent;
                    #endregion

                    #region Foreach İle Labelları Veri Tabanından Çekme İşlemi
                    var oyuncular = secilenFilm.oyuncu.Split(',');

                    int[] konum = { 80, 120, 160 };
                    int x = 0;
                    int[] konumy = { 175, 175, 175 };
                    int y = 0;
                    foreach (var oyuncu in oyuncular)
                    {
                        Label l1 = new Label();
                        l1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                        l1.Size = new System.Drawing.Size(500, 30);
                        l1.Location = new Point(konumy[y], konum[x]);
                        l1.Text = oyuncu.TrimStart();
                        l1.BackColor = Color.Transparent;
                        l1.Font = new Font("Comic Sans MS", 14, FontStyle.Regular);
                        x++;

                        resim.Controls.Add(l1);
                    }
                    #endregion

                    #region Label Yönetmen Oluşturma Ve Özelleştirme
                    Label lblIMDB = new Label();
                    lblIMDB.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                    lblIMDB.Text = "IMDB";
                    lblIMDB.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                    lblIMDB.Location = new Point(175, 200);
                    lblIMDB.Size = new System.Drawing.Size(137, 34);
                    lblIMDB.BackColor = Color.Transparent;

                    Label lblIMDBp = new Label();
                    lblIMDBp.Location = new Point(175, 230);
                    lblIMDBp.Text = secilenFilm.puan.ToString();
                    lblIMDBp.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                    lblIMDBp.Size = new System.Drawing.Size(155, 34);
                    lblIMDBp.BackColor = Color.Transparent;
                    lblIMDBp.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);


                    #endregion

                    #region Label Açıklama Oluşturma Özelleştirme
                    Label lblAciklama = new Label();
                    lblAciklama.Font = new Font("Comic Sans MS", 12, FontStyle.Regular);
                    lblAciklama.Text = secilenFilm.aciklama;                    
                    lblAciklama.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                    lblAciklama.BackColor = Color.Transparent;
                    lblAciklama.Location = new Point(10, 288);
                    lblAciklama.Size = new System.Drawing.Size(320, 120);
                    #endregion

                    #region Buton Oluşturma ve Özelliklerini Değiştirme
                    Button btnIzle = new Button();

                    butonSayi[butonSayisi] = "Buton" + butonSayisi;
                    btnIzle.Name = butonSayi[butonSayisi];

                    btnIzle.Text = "İzle";
                    btnIzle.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                    btnIzle.BackColor = Color.Black;
                    btnIzle.FlatStyle = FlatStyle.Flat;
                    btnIzle.Location = new Point(20, 390);
                    btnIzle.Width = 293;
                    btnIzle.Height = 69;
                    btnIzle.Cursor = Cursors.Hand;
                    btnIzle.Font = new Font(btnIzle.Font.FontFamily, 20);
                    btnIzle.Click += BtnIzle_Click;


                    Program.button[butonSayisi] = btnIzle;
                    butonSayisi++;
                    #endregion

                    #region Oluşturulan Tool'ları Forma Ekleme

                    flwlytpnlResim.Controls.Add(resim);
                    resim.Controls.Add(pcrAfis);
                    resim.Controls.Add(lblBaslik);
                    resim.Controls.Add(btnIzle);
                    resim.Controls.Add(lblAciklama);
                    resim.Controls.Add(lblIMDB);
                    resim.Controls.Add(lblIMDBp);

                    #endregion
                }
                txtArama.Text = "";
            }
            
            
        }
        #endregion

        #region Category Selection Process
        int okuma = 0;
        private void cmbKategori_SelectedIndexChanged(object sender, EventArgs e)
        {
            var filmTurIDMain = ((FilmTur)cmbKategori.SelectedItem).filmTurID;
            
            if (okuma >= 0)
            {
                if (filmTurIDMain == 1)
                {
                   
                    mainFilm();
                }

                else if (filmTurIDMain == 2)
                {
                    mainDizi();
                }
                else
                {
                    mainAnime();
                }
                okuma++;
            }
        }
        #endregion

        #region Click Events
        private void BtnIzle_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            char[] harfler = new char[btn.Name.Length];
            string lastChar = btn.Name.Last().ToString();

            //deneme.Split('');

            if (Program.filmYolu[Convert.ToInt32(lastChar)] != null)
            {
                MessageBox.Show(Program.filmYolu[Convert.ToInt32(lastChar)]);
                this.Hide();
                frmMP.Show();
                frmMP.wmpFilm.URL = Program.filmYolu[Convert.ToInt32(lastChar)];
            }
            else
                MessageBox.Show("Film dosyasına ulaşılamadı. Lütfen daha sonra tekrar deneyiniz.", "Dosya  bulunamadı!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void pcrFilmElkle_Click(object sender, EventArgs e)
        {
            frmAdmin frm = new frmAdmin();
            this.Hide();
            frm.Show();
        }

        private void txtArama_Click(object sender, EventArgs e)
        {
            txtArama.Text = "";
        }

        private void pcrLogo_Click(object sender, EventArgs e)
        {
            mainFilm();
        }

        private void pcrCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion



        //-------------------------ÇÖP KUTUSU ALANI! PROJENİN GEÇMİŞ METHODLARINI İÇERİR! DEVELOPER İZNİ OLMADAN DEĞİŞTİRMEYİN LÜTFEN (ByCrystal02)-------------------------\\
        protected void FilmKategori()
        {
            int artis = 0;
            int butonSayisi = 0;
            int pictureBoxSayisi = 0;
            //int labelSayisi = 0;
            var filmler = db.Film.ToList();
            foreach (var film in filmler)
            {

                #region GroupBox Oluşturma ve Özelliklerini Değiştirme
                GroupBox resim = new GroupBox();
                resim.Width = 332;
                resim.Height = 469;
                resim.Margin = new Padding(5);
                resim.Text = film.ad;
                resim.Margin = new Padding(30, 10, 10, 30);
                resim.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                resim.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                resim.BackColor = Color.Black;

                #endregion

                #region PictureBox Oluşturma ve Özelliklerini Değiştirme
                PictureBox pcrAfis = new PictureBox();
                pcrSayi[pictureBoxSayisi] = "Afis" + pictureBoxSayisi;
                pcrAfis.Name = pcrSayi[pictureBoxSayisi];
                pcrAfis.Width = 160;
                pcrAfis.Height = 255;
                pcrAfis.SizeMode = PictureBoxSizeMode.StretchImage;
                pcrAfis.ImageLocation = film.afis;
                pcrAfis.Location = new Point(13, 32);
                filmSayilari[artis] = pcrAfis.ImageLocation;
                artis++;
                Program.pcr[pictureBoxSayisi] = pcrAfis;
                pictureBoxSayisi++;

                #endregion

                #region  Label Oluşturma ve Özelliklerini Değiştirme

                Label lblBaslik = new Label();
                lblBaslik.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblBaslik.Text = "Başrol";
                lblBaslik.Location = new Point(174, 38);
                lblBaslik.Size = new System.Drawing.Size(139, 34);
                lblBaslik.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);
                lblBaslik.BackColor = Color.Transparent;
                #endregion

                #region Foreach İle Labelları Veri Tabanından Çekme İşlemi
                var oyuncular = film.oyuncu.Split(',');

                int[] konum = { 80, 120, 160 };
                int x = 0;
                int[] konumy = { 175, 175, 175 };
                int y = 0;
                foreach (var oyuncu in oyuncular)
                {
                    Label l1 = new Label();
                    l1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                    l1.Size = new System.Drawing.Size(500, 30);
                    l1.Location = new Point(konumy[y], konum[x]);
                    l1.Text = oyuncu;
                    l1.BackColor = Color.Transparent;
                    l1.Font = new Font("Comic Sans MS", 14, FontStyle.Regular);
                    x++;

                    resim.Controls.Add(l1);
                }
                #endregion

                #region Label Puan Oluşturma Ve Özelleştirme
                Label lblIMDB = new Label();
                lblIMDB.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                lblIMDB.Text = "IMDB";
                lblIMDB.Font = new Font("Comic Sans MS", 15, FontStyle.Regular);
                lblIMDB.Location = new Point(175, 200);
                lblIMDB.Size = new System.Drawing.Size(137, 34);
                lblIMDB.BackColor = Color.Transparent;

                Label lblIMDBp = new Label();
                lblIMDBp.Location = new Point(175, 230);
                lblIMDBp.Text = film.puan.ToString();
                lblIMDBp.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblIMDBp.Size = new System.Drawing.Size(155, 34);
                lblIMDBp.BackColor = Color.Transparent;
                lblIMDBp.Font = new Font("Comic Sans MS", 13, FontStyle.Regular);


                #endregion

                #region Label Açıklama Ve Oluşturma Özelleştirme
                Label lblAciklama = new Label();
                lblAciklama.Font = new Font("Comic Sans MS", 12, FontStyle.Regular);
                lblAciklama.Text = film.aciklama;
                lblAciklama.ForeColor = System.Drawing.ColorTranslator.FromHtml("#D6D3D1");
                lblAciklama.BackColor = Color.Transparent;
                lblAciklama.Location = new Point(10, 288);
                lblAciklama.Size = new System.Drawing.Size(320, 120);
                #endregion

                #region Buton Oluşturma ve Özelliklerini Değiştirme
                Button btnIzle = new Button();

                butonSayi[butonSayisi] = "Buton" + butonSayisi;
                btnIzle.Name = butonSayi[butonSayisi];

                btnIzle.Text = "İzle";
                btnIzle.ForeColor = System.Drawing.Color.FromArgb(219, 0, 0);
                btnIzle.BackColor = Color.Black;
                btnIzle.FlatStyle = FlatStyle.Flat;
                btnIzle.Location = new Point(20, 390);
                btnIzle.Width = 293;
                btnIzle.Height = 69;
                btnIzle.Font = new Font(btnIzle.Font.FontFamily, 20);

                Program.filmYolu[butonSayisi] = film.filmDosyaYolu;
                btnIzle.Name = film.filmDosyaYolu;
                btnIzle.Click += BtnIzle_Click;


                Program.button[butonSayisi] = btnIzle;
                butonSayisi++;
                #endregion

                #region Oluşturulan Tool'ları Forma Ekleme

                flwlytpnlResim.Controls.Add(resim);
                resim.Controls.Add(pcrAfis);
                resim.Controls.Add(lblBaslik);
                resim.Controls.Add(btnIzle);
                resim.Controls.Add(lblAciklama);
                resim.Controls.Add(lblIMDB);
                resim.Controls.Add(lblIMDBp);



                #endregion
            }
        }

        
    }
}
