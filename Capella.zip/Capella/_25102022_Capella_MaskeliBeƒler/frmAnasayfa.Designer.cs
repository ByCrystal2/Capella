﻿namespace _25102022_Capella_MaskeliBeşler
{
    partial class frmAnasayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAnasayfa));
            this.pnlTblLayout = new System.Windows.Forms.TableLayoutPanel();
            this.pnlLayout = new System.Windows.Forms.Panel();
            this.pcrCikis = new System.Windows.Forms.PictureBox();
            this.pcrFilmElkle = new System.Windows.Forms.PictureBox();
            this.cmbKategori = new System.Windows.Forms.ComboBox();
            this.pcrAra = new System.Windows.Forms.PictureBox();
            this.txtArama = new System.Windows.Forms.TextBox();
            this.pcrLogo = new System.Windows.Forms.PictureBox();
            this.flwlytpnlResim = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlTblLayout.SuspendLayout();
            this.pnlLayout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcrCikis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrFilmElkle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrAra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTblLayout
            // 
            this.pnlTblLayout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTblLayout.BackColor = System.Drawing.Color.Black;
            this.pnlTblLayout.ColumnCount = 1;
            this.pnlTblLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlTblLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.pnlTblLayout.Controls.Add(this.pnlLayout, 0, 0);
            this.pnlTblLayout.Location = new System.Drawing.Point(-4, -3);
            this.pnlTblLayout.Name = "pnlTblLayout";
            this.pnlTblLayout.RowCount = 1;
            this.pnlTblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlTblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.pnlTblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.pnlTblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.pnlTblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.pnlTblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.pnlTblLayout.Size = new System.Drawing.Size(2084, 108);
            this.pnlTblLayout.TabIndex = 1;
            // 
            // pnlLayout
            // 
            this.pnlLayout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlLayout.BackColor = System.Drawing.Color.Black;
            this.pnlLayout.Controls.Add(this.pcrCikis);
            this.pnlLayout.Controls.Add(this.pcrFilmElkle);
            this.pnlLayout.Controls.Add(this.cmbKategori);
            this.pnlLayout.Controls.Add(this.pcrAra);
            this.pnlLayout.Controls.Add(this.txtArama);
            this.pnlLayout.Controls.Add(this.pcrLogo);
            this.pnlLayout.Location = new System.Drawing.Point(3, 3);
            this.pnlLayout.Name = "pnlLayout";
            this.pnlLayout.Size = new System.Drawing.Size(2078, 102);
            this.pnlLayout.TabIndex = 0;
            // 
            // pcrCikis
            // 
            this.pcrCikis.BackColor = System.Drawing.Color.Transparent;
            this.pcrCikis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcrCikis.Image = ((System.Drawing.Image)(resources.GetObject("pcrCikis.Image")));
            this.pcrCikis.Location = new System.Drawing.Point(32, 38);
            this.pcrCikis.Name = "pcrCikis";
            this.pcrCikis.Size = new System.Drawing.Size(43, 38);
            this.pcrCikis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrCikis.TabIndex = 3;
            this.pcrCikis.TabStop = false;
            this.pcrCikis.Click += new System.EventHandler(this.pcrCikis_Click);
            // 
            // pcrFilmElkle
            // 
            this.pcrFilmElkle.BackColor = System.Drawing.Color.Transparent;
            this.pcrFilmElkle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcrFilmElkle.Image = ((System.Drawing.Image)(resources.GetObject("pcrFilmElkle.Image")));
            this.pcrFilmElkle.Location = new System.Drawing.Point(1477, 38);
            this.pcrFilmElkle.Name = "pcrFilmElkle";
            this.pcrFilmElkle.Size = new System.Drawing.Size(43, 38);
            this.pcrFilmElkle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrFilmElkle.TabIndex = 2;
            this.pcrFilmElkle.TabStop = false;
            this.pcrFilmElkle.Click += new System.EventHandler(this.pcrFilmElkle_Click);
            // 
            // cmbKategori
            // 
            this.cmbKategori.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbKategori.BackColor = System.Drawing.Color.IndianRed;
            this.cmbKategori.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbKategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKategori.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbKategori.Font = new System.Drawing.Font("Yu Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbKategori.IntegralHeight = false;
            this.cmbKategori.Location = new System.Drawing.Point(1245, 58);
            this.cmbKategori.MaximumSize = new System.Drawing.Size(9999, 0);
            this.cmbKategori.Name = "cmbKategori";
            this.cmbKategori.Size = new System.Drawing.Size(204, 43);
            this.cmbKategori.TabIndex = 0;
            this.cmbKategori.SelectedIndexChanged += new System.EventHandler(this.cmbKategori_SelectedIndexChanged);
            // 
            // pcrAra
            // 
            this.pcrAra.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pcrAra.BackColor = System.Drawing.Color.IndianRed;
            this.pcrAra.Image = ((System.Drawing.Image)(resources.GetObject("pcrAra.Image")));
            this.pcrAra.Location = new System.Drawing.Point(1413, 21);
            this.pcrAra.Name = "pcrAra";
            this.pcrAra.Size = new System.Drawing.Size(30, 20);
            this.pcrAra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrAra.TabIndex = 1;
            this.pcrAra.TabStop = false;
            // 
            // txtArama
            // 
            this.txtArama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtArama.BackColor = System.Drawing.Color.IndianRed;
            this.txtArama.Font = new System.Drawing.Font("Sylfaen", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtArama.Location = new System.Drawing.Point(1245, 12);
            this.txtArama.Multiline = true;
            this.txtArama.Name = "txtArama";
            this.txtArama.Size = new System.Drawing.Size(204, 36);
            this.txtArama.TabIndex = 0;
            this.txtArama.Click += new System.EventHandler(this.txtArama_Click);
            this.txtArama.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtArama_KeyDown);
            // 
            // pcrLogo
            // 
            this.pcrLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcrLogo.Image = ((System.Drawing.Image)(resources.GetObject("pcrLogo.Image")));
            this.pcrLogo.Location = new System.Drawing.Point(658, 15);
            this.pcrLogo.Name = "pcrLogo";
            this.pcrLogo.Size = new System.Drawing.Size(224, 73);
            this.pcrLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrLogo.TabIndex = 0;
            this.pcrLogo.TabStop = false;
            this.pcrLogo.Click += new System.EventHandler(this.pcrLogo_Click);
            // 
            // flwlytpnlResim
            // 
            this.flwlytpnlResim.AutoScroll = true;
            this.flwlytpnlResim.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flwlytpnlResim.BackColor = System.Drawing.SystemColors.Desktop;
            this.flwlytpnlResim.Location = new System.Drawing.Point(-1, 108);
            this.flwlytpnlResim.Margin = new System.Windows.Forms.Padding(15, 3, 10, 3);
            this.flwlytpnlResim.Name = "flwlytpnlResim";
            this.flwlytpnlResim.Size = new System.Drawing.Size(1845, 1055);
            this.flwlytpnlResim.TabIndex = 0;
            // 
            // frmAnasayfa
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(10, 10);
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1830, 982);
            this.Controls.Add(this.flwlytpnlResim);
            this.Controls.Add(this.pnlTblLayout);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAnasayfa";
            this.Text = "frmAnasayfa";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmAnasayfa_Load);
            this.pnlTblLayout.ResumeLayout(false);
            this.pnlLayout.ResumeLayout(false);
            this.pnlLayout.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcrCikis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrFilmElkle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrAra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel pnlTblLayout;
        private System.Windows.Forms.Panel pnlLayout;
        private System.Windows.Forms.PictureBox pcrAra;
        private System.Windows.Forms.TextBox txtArama;
        private System.Windows.Forms.PictureBox pcrLogo;
        private System.Windows.Forms.ComboBox cmbKategori;
        private System.Windows.Forms.FlowLayoutPanel flwlytpnlResim;
        private System.Windows.Forms.PictureBox pcrFilmElkle;
        private System.Windows.Forms.PictureBox pcrCikis;
    }
}