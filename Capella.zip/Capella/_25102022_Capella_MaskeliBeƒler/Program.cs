﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25102022_Capella_MaskeliBeşler
{
    internal static class Program
    {
        
        public static string[] filmYolu;
        //public static string[] butonName;
        public static Button[] button;
        public static PictureBox[] pcr;
        
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmAnasayfa());
        }
    }
}
