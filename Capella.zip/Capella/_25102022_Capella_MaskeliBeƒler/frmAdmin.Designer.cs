﻿namespace _25102022_Capella_MaskeliBeşler
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdmin));
            this.txtAfis = new System.Windows.Forms.TextBox();
            this.txtSure = new System.Windows.Forms.TextBox();
            this.txtKonu = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pctrAfis = new System.Windows.Forms.PictureBox();
            this.btnAfisEkle = new System.Windows.Forms.Button();
            this.txtOyuncu = new System.Windows.Forms.TextBox();
            this.rchtxtAciklama = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnFilmGuncelle = new System.Windows.Forms.Button();
            this.btnFilmEkle = new System.Windows.Forms.Button();
            this.btnFilmSil = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gridFilm = new System.Windows.Forms.DataGridView();
            this.fileDialogAfis = new System.Windows.Forms.OpenFileDialog();
            this.cmbTur = new System.Windows.Forms.ComboBox();
            this.btnFilmDosyasıEkle = new System.Windows.Forms.Button();
            this.fileDialogFilm = new System.Windows.Forms.OpenFileDialog();
            this.nupCikisTarihi = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFilmDosyaYolu = new System.Windows.Forms.TextBox();
            this.txtPuan = new System.Windows.Forms.TextBox();
            this.txtFilmAra = new System.Windows.Forms.TextBox();
            this.lblGörüntüle = new System.Windows.Forms.Label();
            this.pcrCikis = new System.Windows.Forms.PictureBox();
            this.pcrBack = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pctrAfis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridFilm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupCikisTarihi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrCikis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBack)).BeginInit();
            this.SuspendLayout();
            // 
            // txtAfis
            // 
            this.txtAfis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAfis.BackColor = System.Drawing.Color.Black;
            this.txtAfis.Font = new System.Drawing.Font("Mongolian Baiti", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAfis.ForeColor = System.Drawing.Color.White;
            this.txtAfis.Location = new System.Drawing.Point(668, 895);
            this.txtAfis.Name = "txtAfis";
            this.txtAfis.ReadOnly = true;
            this.txtAfis.Size = new System.Drawing.Size(148, 34);
            this.txtAfis.TabIndex = 5;
            // 
            // txtSure
            // 
            this.txtSure.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSure.BackColor = System.Drawing.Color.Black;
            this.txtSure.Font = new System.Drawing.Font("Mongolian Baiti", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSure.ForeColor = System.Drawing.Color.White;
            this.txtSure.Location = new System.Drawing.Point(668, 736);
            this.txtSure.Name = "txtSure";
            this.txtSure.Size = new System.Drawing.Size(148, 34);
            this.txtSure.TabIndex = 1;
            this.txtSure.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSure_KeyPress);
            // 
            // txtKonu
            // 
            this.txtKonu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtKonu.BackColor = System.Drawing.Color.Black;
            this.txtKonu.Font = new System.Drawing.Font("Mongolian Baiti", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKonu.ForeColor = System.Drawing.Color.White;
            this.txtKonu.Location = new System.Drawing.Point(668, 777);
            this.txtKonu.Name = "txtKonu";
            this.txtKonu.Size = new System.Drawing.Size(148, 34);
            this.txtKonu.TabIndex = 2;
            // 
            // txtAd
            // 
            this.txtAd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAd.BackColor = System.Drawing.Color.Black;
            this.txtAd.Font = new System.Drawing.Font("Mongolian Baiti", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAd.ForeColor = System.Drawing.Color.White;
            this.txtAd.Location = new System.Drawing.Point(668, 696);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(148, 34);
            this.txtAd.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.DarkRed;
            this.label19.Location = new System.Drawing.Point(578, 892);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 31);
            this.label19.TabIndex = 97;
            this.label19.Text = "Afiş :";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.DarkRed;
            this.label17.Location = new System.Drawing.Point(570, 819);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 31);
            this.label17.TabIndex = 96;
            this.label17.Text = "Puan :";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkRed;
            this.label10.Location = new System.Drawing.Point(593, 697);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 31);
            this.label10.TabIndex = 95;
            this.label10.Text = "Ad :";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkRed;
            this.label9.Location = new System.Drawing.Point(575, 735);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 31);
            this.label9.TabIndex = 94;
            this.label9.Text = "Sure :";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkRed;
            this.label8.Location = new System.Drawing.Point(563, 777);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 31);
            this.label8.TabIndex = 93;
            this.label8.Text = "Konu :";
            // 
            // pctrAfis
            // 
            this.pctrAfis.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pctrAfis.Location = new System.Drawing.Point(835, 709);
            this.pctrAfis.Name = "pctrAfis";
            this.pctrAfis.Size = new System.Drawing.Size(176, 252);
            this.pctrAfis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctrAfis.TabIndex = 100;
            this.pctrAfis.TabStop = false;
            // 
            // btnAfisEkle
            // 
            this.btnAfisEkle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAfisEkle.BackColor = System.Drawing.Color.Black;
            this.btnAfisEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.btnAfisEkle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAfisEkle.Location = new System.Drawing.Point(1017, 859);
            this.btnAfisEkle.Name = "btnAfisEkle";
            this.btnAfisEkle.Size = new System.Drawing.Size(176, 54);
            this.btnAfisEkle.TabIndex = 8;
            this.btnAfisEkle.Text = "Afiş Ekle";
            this.btnAfisEkle.UseVisualStyleBackColor = false;
            this.btnAfisEkle.Click += new System.EventHandler(this.btnAfisEkle_Click);
            // 
            // txtOyuncu
            // 
            this.txtOyuncu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtOyuncu.BackColor = System.Drawing.Color.Black;
            this.txtOyuncu.Font = new System.Drawing.Font("Mongolian Baiti", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOyuncu.ForeColor = System.Drawing.Color.White;
            this.txtOyuncu.Location = new System.Drawing.Point(1370, 706);
            this.txtOyuncu.Name = "txtOyuncu";
            this.txtOyuncu.Size = new System.Drawing.Size(200, 34);
            this.txtOyuncu.TabIndex = 9;
            // 
            // rchtxtAciklama
            // 
            this.rchtxtAciklama.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rchtxtAciklama.BackColor = System.Drawing.SystemColors.MenuText;
            this.rchtxtAciklama.ForeColor = System.Drawing.Color.White;
            this.rchtxtAciklama.Location = new System.Drawing.Point(1370, 798);
            this.rchtxtAciklama.MaxLength = 159;
            this.rchtxtAciklama.Name = "rchtxtAciklama";
            this.rchtxtAciklama.Size = new System.Drawing.Size(200, 166);
            this.rchtxtAciklama.TabIndex = 11;
            this.rchtxtAciklama.Text = "";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.DarkRed;
            this.label18.Location = new System.Drawing.Point(1204, 793);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(143, 31);
            this.label18.TabIndex = 112;
            this.label18.Text = "Açıklama :";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkRed;
            this.label13.Location = new System.Drawing.Point(1274, 748);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 31);
            this.label13.TabIndex = 111;
            this.label13.Text = "Tür :";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DarkRed;
            this.label16.Location = new System.Drawing.Point(1222, 709);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 31);
            this.label16.TabIndex = 108;
            this.label16.Text = "Oyuncu :";
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.Color.Maroon;
            this.panel4.Location = new System.Drawing.Point(551, 990);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1196, 10);
            this.panel4.TabIndex = 105;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.Color.Maroon;
            this.panel2.Location = new System.Drawing.Point(551, 642);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1196, 10);
            this.panel2.TabIndex = 106;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.Color.Maroon;
            this.panel3.Location = new System.Drawing.Point(551, 604);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1196, 10);
            this.panel3.TabIndex = 104;
            // 
            // btnFilmGuncelle
            // 
            this.btnFilmGuncelle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFilmGuncelle.BackColor = System.Drawing.Color.Black;
            this.btnFilmGuncelle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilmGuncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilmGuncelle.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilmGuncelle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnFilmGuncelle.Location = new System.Drawing.Point(1586, 877);
            this.btnFilmGuncelle.Name = "btnFilmGuncelle";
            this.btnFilmGuncelle.Size = new System.Drawing.Size(135, 47);
            this.btnFilmGuncelle.TabIndex = 14;
            this.btnFilmGuncelle.Text = "Güncelle";
            this.btnFilmGuncelle.UseVisualStyleBackColor = false;
            this.btnFilmGuncelle.Click += new System.EventHandler(this.btnFilmGuncelle_Click);
            // 
            // btnFilmEkle
            // 
            this.btnFilmEkle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFilmEkle.BackColor = System.Drawing.Color.Black;
            this.btnFilmEkle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilmEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilmEkle.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilmEkle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnFilmEkle.Location = new System.Drawing.Point(1586, 793);
            this.btnFilmEkle.Name = "btnFilmEkle";
            this.btnFilmEkle.Size = new System.Drawing.Size(135, 47);
            this.btnFilmEkle.TabIndex = 13;
            this.btnFilmEkle.Text = "Ekle";
            this.btnFilmEkle.UseVisualStyleBackColor = false;
            this.btnFilmEkle.Click += new System.EventHandler(this.btnFilmEkle_Click);
            // 
            // btnFilmSil
            // 
            this.btnFilmSil.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFilmSil.BackColor = System.Drawing.Color.Black;
            this.btnFilmSil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilmSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilmSil.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilmSil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnFilmSil.Location = new System.Drawing.Point(1586, 709);
            this.btnFilmSil.Name = "btnFilmSil";
            this.btnFilmSil.Size = new System.Drawing.Size(135, 47);
            this.btnFilmSil.TabIndex = 12;
            this.btnFilmSil.Text = "Sil";
            this.btnFilmSil.UseVisualStyleBackColor = false;
            this.btnFilmSil.Click += new System.EventHandler(this.btnFilmSil_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 479);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(440, 135);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 118;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 35F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(458, 515);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(309, 63);
            this.label2.TabIndex = 117;
            this.label2.Text = "Film Bilgisi";
            // 
            // gridFilm
            // 
            this.gridFilm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.gridFilm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridFilm.BackgroundColor = System.Drawing.Color.Black;
            this.gridFilm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridFilm.Location = new System.Drawing.Point(0, 58);
            this.gridFilm.Name = "gridFilm";
            this.gridFilm.RowHeadersWidth = 51;
            this.gridFilm.RowTemplate.Height = 24;
            this.gridFilm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridFilm.Size = new System.Drawing.Size(1748, 211);
            this.gridFilm.TabIndex = 119;
            this.gridFilm.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridFilm_CellClick);
            // 
            // fileDialogAfis
            // 
            this.fileDialogAfis.FileName = "Afiş Seçmedin.";
            this.fileDialogAfis.Title = "Afiş Dosyasını Seç";
            // 
            // cmbTur
            // 
            this.cmbTur.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbTur.BackColor = System.Drawing.Color.Black;
            this.cmbTur.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTur.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbTur.ForeColor = System.Drawing.Color.White;
            this.cmbTur.FormattingEnabled = true;
            this.cmbTur.Location = new System.Drawing.Point(1370, 749);
            this.cmbTur.Name = "cmbTur";
            this.cmbTur.Size = new System.Drawing.Size(200, 30);
            this.cmbTur.TabIndex = 10;
            // 
            // btnFilmDosyasıEkle
            // 
            this.btnFilmDosyasıEkle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFilmDosyasıEkle.BackColor = System.Drawing.Color.Black;
            this.btnFilmDosyasıEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnFilmDosyasıEkle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnFilmDosyasıEkle.Location = new System.Drawing.Point(1017, 768);
            this.btnFilmDosyasıEkle.Name = "btnFilmDosyasıEkle";
            this.btnFilmDosyasıEkle.Size = new System.Drawing.Size(176, 54);
            this.btnFilmDosyasıEkle.TabIndex = 7;
            this.btnFilmDosyasıEkle.Text = "Film Dosyası Ekle";
            this.btnFilmDosyasıEkle.UseVisualStyleBackColor = false;
            this.btnFilmDosyasıEkle.Click += new System.EventHandler(this.btnFilmDosyasıEkle_Click);
            // 
            // fileDialogFilm
            // 
            this.fileDialogFilm.FileName = "Film Dosyasını Seç";
            // 
            // nupCikisTarihi
            // 
            this.nupCikisTarihi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nupCikisTarihi.BackColor = System.Drawing.Color.Black;
            this.nupCikisTarihi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nupCikisTarihi.ForeColor = System.Drawing.Color.White;
            this.nupCikisTarihi.Location = new System.Drawing.Point(668, 859);
            this.nupCikisTarihi.Name = "nupCikisTarihi";
            this.nupCikisTarihi.Size = new System.Drawing.Size(148, 30);
            this.nupCikisTarihi.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(491, 859);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 31);
            this.label1.TabIndex = 95;
            this.label1.Text = "Çıkış Tarihi :";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(417, 933);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(239, 31);
            this.label3.TabIndex = 124;
            this.label3.Text = "Film Dosya Yolu :";
            // 
            // txtFilmDosyaYolu
            // 
            this.txtFilmDosyaYolu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFilmDosyaYolu.BackColor = System.Drawing.Color.Black;
            this.txtFilmDosyaYolu.Font = new System.Drawing.Font("Mongolian Baiti", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFilmDosyaYolu.ForeColor = System.Drawing.Color.White;
            this.txtFilmDosyaYolu.Location = new System.Drawing.Point(668, 934);
            this.txtFilmDosyaYolu.Name = "txtFilmDosyaYolu";
            this.txtFilmDosyaYolu.ReadOnly = true;
            this.txtFilmDosyaYolu.Size = new System.Drawing.Size(148, 34);
            this.txtFilmDosyaYolu.TabIndex = 6;
            // 
            // txtPuan
            // 
            this.txtPuan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPuan.BackColor = System.Drawing.Color.Black;
            this.txtPuan.Font = new System.Drawing.Font("Mongolian Baiti", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPuan.ForeColor = System.Drawing.Color.White;
            this.txtPuan.Location = new System.Drawing.Point(668, 816);
            this.txtPuan.Name = "txtPuan";
            this.txtPuan.Size = new System.Drawing.Size(148, 34);
            this.txtPuan.TabIndex = 126;
            this.txtPuan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPuan_KeyPress);
            // 
            // txtFilmAra
            // 
            this.txtFilmAra.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.txtFilmAra.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtFilmAra.ForeColor = System.Drawing.Color.Snow;
            this.txtFilmAra.Location = new System.Drawing.Point(1470, 275);
            this.txtFilmAra.Multiline = true;
            this.txtFilmAra.Name = "txtFilmAra";
            this.txtFilmAra.Size = new System.Drawing.Size(266, 43);
            this.txtFilmAra.TabIndex = 127;
            this.txtFilmAra.Click += new System.EventHandler(this.txtFilmAra_Click);
            this.txtFilmAra.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFilmAra_KeyDown);
            // 
            // lblGörüntüle
            // 
            this.lblGörüntüle.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblGörüntüle.AutoSize = true;
            this.lblGörüntüle.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lblGörüntüle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblGörüntüle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGörüntüle.ForeColor = System.Drawing.Color.Snow;
            this.lblGörüntüle.Location = new System.Drawing.Point(1481, 321);
            this.lblGörüntüle.Name = "lblGörüntüle";
            this.lblGörüntüle.Size = new System.Drawing.Size(220, 22);
            this.lblGörüntüle.TabIndex = 128;
            this.lblGörüntüle.Text = "Tüm Filmleri Görüntüle.";
            this.lblGörüntüle.Visible = false;
            this.lblGörüntüle.Click += new System.EventHandler(this.lblGörüntüle_Click);
            // 
            // pcrCikis
            // 
            this.pcrCikis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pcrCikis.BackColor = System.Drawing.Color.Transparent;
            this.pcrCikis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcrCikis.Image = ((System.Drawing.Image)(resources.GetObject("pcrCikis.Image")));
            this.pcrCikis.Location = new System.Drawing.Point(1657, 12);
            this.pcrCikis.Name = "pcrCikis";
            this.pcrCikis.Size = new System.Drawing.Size(79, 64);
            this.pcrCikis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrCikis.TabIndex = 129;
            this.pcrCikis.TabStop = false;
            this.pcrCikis.Click += new System.EventHandler(this.pcrCikis_Click);
            // 
            // pcrBack
            // 
            this.pcrBack.BackColor = System.Drawing.Color.Transparent;
            this.pcrBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcrBack.Image = ((System.Drawing.Image)(resources.GetObject("pcrBack.Image")));
            this.pcrBack.Location = new System.Drawing.Point(12, 6);
            this.pcrBack.Name = "pcrBack";
            this.pcrBack.Size = new System.Drawing.Size(92, 81);
            this.pcrBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrBack.TabIndex = 130;
            this.pcrBack.TabStop = false;
            this.pcrBack.Click += new System.EventHandler(this.pcrBack_Click);
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1748, 998);
            this.Controls.Add(this.pcrBack);
            this.Controls.Add(this.pcrCikis);
            this.Controls.Add(this.lblGörüntüle);
            this.Controls.Add(this.txtFilmAra);
            this.Controls.Add(this.txtPuan);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFilmDosyaYolu);
            this.Controls.Add(this.nupCikisTarihi);
            this.Controls.Add(this.btnFilmDosyasıEkle);
            this.Controls.Add(this.cmbTur);
            this.Controls.Add(this.gridFilm);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtOyuncu);
            this.Controls.Add(this.rchtxtAciklama);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnFilmGuncelle);
            this.Controls.Add(this.btnFilmEkle);
            this.Controls.Add(this.btnFilmSil);
            this.Controls.Add(this.pctrAfis);
            this.Controls.Add(this.btnAfisEkle);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtAfis);
            this.Controls.Add(this.txtSure);
            this.Controls.Add(this.txtKonu);
            this.Controls.Add(this.txtAd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAdmin";
            this.Text = "frmAdmin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctrAfis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridFilm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupCikisTarihi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrCikis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtAfis;
        private System.Windows.Forms.TextBox txtSure;
        private System.Windows.Forms.TextBox txtKonu;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pctrAfis;
        private System.Windows.Forms.Button btnAfisEkle;
        private System.Windows.Forms.TextBox txtOyuncu;
        private System.Windows.Forms.RichTextBox rchtxtAciklama;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnFilmGuncelle;
        private System.Windows.Forms.Button btnFilmEkle;
        private System.Windows.Forms.Button btnFilmSil;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView gridFilm;
        private System.Windows.Forms.OpenFileDialog fileDialogAfis;
        private System.Windows.Forms.ComboBox cmbTur;
        private System.Windows.Forms.Button btnFilmDosyasıEkle;
        private System.Windows.Forms.OpenFileDialog fileDialogFilm;
        private System.Windows.Forms.NumericUpDown nupCikisTarihi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFilmDosyaYolu;
        private System.Windows.Forms.TextBox txtPuan;
        private System.Windows.Forms.TextBox txtFilmAra;
        private System.Windows.Forms.Label lblGörüntüle;
        private System.Windows.Forms.PictureBox pcrCikis;
        private System.Windows.Forms.PictureBox pcrBack;
    }
}