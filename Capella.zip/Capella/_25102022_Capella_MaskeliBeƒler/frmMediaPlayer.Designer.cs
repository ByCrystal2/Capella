﻿namespace _25102022_Capella_MaskeliBeşler
{
    partial class frmMediaPlayer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMediaPlayer));
            this.lblNasilKullanilir = new System.Windows.Forms.Label();
            this.wmpFilm = new AxWMPLib.AxWindowsMediaPlayer();
            this.pcrBack = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.wmpFilm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBack)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNasilKullanilir
            // 
            this.lblNasilKullanilir.AutoSize = true;
            this.lblNasilKullanilir.BackColor = System.Drawing.Color.Black;
            this.lblNasilKullanilir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblNasilKullanilir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNasilKullanilir.ForeColor = System.Drawing.SystemColors.Control;
            this.lblNasilKullanilir.Location = new System.Drawing.Point(557, 9);
            this.lblNasilKullanilir.Name = "lblNasilKullanilir";
            this.lblNasilKullanilir.Size = new System.Drawing.Size(208, 22);
            this.lblNasilKullanilir.TabIndex = 2;
            this.lblNasilKullanilir.Text = "Medya nasıl kullanılır?";
            this.lblNasilKullanilir.Click += new System.EventHandler(this.lblNasilKullanilir_Click);
            // 
            // wmpFilm
            // 
            this.wmpFilm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wmpFilm.Enabled = true;
            this.wmpFilm.Location = new System.Drawing.Point(0, 0);
            this.wmpFilm.Name = "wmpFilm";
            this.wmpFilm.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("wmpFilm.OcxState")));
            this.wmpFilm.Size = new System.Drawing.Size(800, 450);
            this.wmpFilm.TabIndex = 0;
            this.wmpFilm.KeyPressEvent += new AxWMPLib._WMPOCXEvents_KeyPressEventHandler(this.wmpFilm_KeyPressEvent);
            // 
            // pcrBack
            // 
            this.pcrBack.BackColor = System.Drawing.Color.Black;
            this.pcrBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcrBack.Image = ((System.Drawing.Image)(resources.GetObject("pcrBack.Image")));
            this.pcrBack.Location = new System.Drawing.Point(0, 0);
            this.pcrBack.Name = "pcrBack";
            this.pcrBack.Size = new System.Drawing.Size(51, 46);
            this.pcrBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrBack.TabIndex = 131;
            this.pcrBack.TabStop = false;
            this.pcrBack.Click += new System.EventHandler(this.pcrBack_Click);
            // 
            // frmMediaPlayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pcrBack);
            this.Controls.Add(this.lblNasilKullanilir);
            this.Controls.Add(this.wmpFilm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmMediaPlayer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Capella Media";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMediaPlayer_FormClosed);
            this.Load += new System.EventHandler(this.frmMediaPlayer_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmMediaPlayer_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.wmpFilm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrBack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public AxWMPLib.AxWindowsMediaPlayer wmpFilm;
        private System.Windows.Forms.Label lblNasilKullanilir;
        private System.Windows.Forms.PictureBox pcrBack;
    }
}