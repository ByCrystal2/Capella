﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace _25102022_Capella_MaskeliBeşler.Models
{
    public partial class CapellaContext : DbContext
    {
        public CapellaContext()
            : base("name=CapellaContext")
        {
        }

        public virtual DbSet<Film> Film { get; set; }
        public virtual DbSet<FilmTur> FilmTur { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Film>()
                .Property(e => e.konu)
                .IsUnicode(false);

            modelBuilder.Entity<Film>()
                .Property(e => e.afis)
                .IsUnicode(false);

            modelBuilder.Entity<Film>()
                .Property(e => e.aciklama)
                .IsUnicode(false);

            modelBuilder.Entity<Film>()
                .Property(e => e.filmDosyaYolu)
                .IsUnicode(false);
        }
    }
}
