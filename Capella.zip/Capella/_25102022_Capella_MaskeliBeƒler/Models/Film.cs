namespace _25102022_Capella_MaskeliBeşler.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Film")]
    public partial class Film
    {
        public int FilmID { get; set; }

        [StringLength(50)]
        public string ad { get; set; }

        public double? sure { get; set; }

        [Column(TypeName = "text")]
        public string konu { get; set; }

        public double? puan { get; set; }

        [StringLength(50)]
        public string oyuncu { get; set; }

        public int? filmTurId { get; set; }

        [Column(TypeName = "text")]
        public string afis { get; set; }

        public short? cikisTarihi { get; set; }

        [Column(TypeName = "text")]
        public string aciklama { get; set; }

        [Column(TypeName = "text")]
        public string filmDosyaYolu { get; set; }

        public virtual FilmTur FilmTur { get; set; }
    }
}
