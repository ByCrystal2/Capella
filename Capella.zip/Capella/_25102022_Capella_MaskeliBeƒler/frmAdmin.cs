﻿using _25102022_Capella_MaskeliBeşler.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25102022_Capella_MaskeliBeşler
{
    public partial class frmAdmin : Form
    {        
        public frmAdmin()
        {
            InitializeComponent();
        }

        bool adminControl = true;
        string arama = "";
        CapellaContext db = new CapellaContext();
        

        #region Form Load
        
        private void frmAdmin_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Lütfen filme ekleyeceğiniz oyuncuları ',' ile ayırınız.", "By ByCrystal02", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            nupCikisTarihi.Maximum = DateTime.Now.Year;            
            nupCikisTarihi.Minimum = 1900;
            txtPuan.MaxLength = 3;
            txtSure.MaxLength = 3;
            txtFilmAra.BackColor = Color.FromArgb(81, 36, 36);
            txtFilmAra.Text = "Film Ara...";
            kategoriConnection();
            ListeleFilm();
            TemizleFilm();
        }
        #endregion

        #region Connection settings
        public void kategoriConnection()
        {
            var kategori = db.FilmTur.ToList();
            cmbTur.DataSource = kategori;
            cmbTur.DisplayMember = "ad";
            cmbTur.ValueMember = "filmTurID";
            cmbTur.Font = new Font(cmbTur.Font.FontFamily, 11);
        }
        #endregion

        #region Routine Methods
        public void TemizleFilm()
        {
            
            
            txtAd.Text = "";
            txtSure.Text = "";
            txtKonu.Text = "";
            txtPuan.Text = "";
            txtAfis.Text = "";
            nupCikisTarihi.Value = 1900;
            txtFilmDosyaYolu.Text = "";            
            pctrAfis.ImageLocation = "";
            rchtxtAciklama.Text = "";
            txtOyuncu.Text = "";
            txtAd.Focus();
        }
        public void ListeleFilm()
        {
            ////gridBilet.DataSource = db.Bilet.ToList(); tümünü listelemek için.
                        
            gridFilm.DataSource = db.Film.Select(x =>
                new
                {
                    x.FilmID,
                 x.ad,
                 x.sure,
                 x.konu,
                 x.puan,
                 x.oyuncu,
                 tur = x.FilmTur.ad,
                 x.afis,
                 x.cikisTarihi,
                 x.aciklama,
                 x.filmDosyaYolu
                 
                }).ToList();
            
        }
        #endregion

        #region Admin Form Controls
        public void adminControls()
        {
            
            if (txtAd.Text == "" || txtSure.Text == "" || txtKonu.Text == "" || txtPuan.Text == "" || txtAfis.Text == "" || txtAfis.Text == "Afiş Seçmedin." || txtFilmDosyaYolu.Text == "" || txtFilmDosyaYolu.Text == "Film Dosyasını Seç" || txtOyuncu.Text == "" || rchtxtAciklama.Text == "")
            {
                MessageBox.Show("Lütfen bilgilerin eksiksiz girildiğinden emin olunuz.", "Bilgiler Eksik!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ListeleFilm();
                adminControl = false;
                return;
            }
        }
        #endregion

        #region Click Events
        private void btnAfisEkle_Click(object sender, EventArgs e)
        {
            fileDialogAfis.ShowDialog();
            pctrAfis.ImageLocation = fileDialogAfis.FileName;
            txtAfis.Text = fileDialogAfis.FileName;
        }
        private void btnFilmSil_Click(object sender, EventArgs e)
        {
            int filmID = (int)gridFilm.SelectedRows[0].Cells[0].Value;
            Film film = db.Film.Where(x => x.FilmID == filmID).SingleOrDefault();
            if (film != null) //bulunduysa sil
            {
                DialogResult sonuc = MessageBox.Show("Silmek istediğinize emin misiniz ?", "Film Silme", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (sonuc == DialogResult.Yes) //Silme işlemine evet denmesi durumunda gerçekleşecek.
                {
                    db.Film.Remove(film);
                    db.SaveChanges();
                    ListeleFilm();
                    MessageBox.Show("Başarılı silme işlemi.", "Başarılı!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else//Silme işlemine hayır denmesi durumunda gerçekleşecek.
                {
                    MessageBox.Show("İşlem iptal edildi.", "Film İptal", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
                MessageBox.Show("Seçilen Film Bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            TemizleFilm();
        }
        private void btnFilmEkle_Click(object sender, EventArgs e)
        {
            adminControl = true;
            adminControls();

            if (adminControl)
            {
                DialogResult sonuc = MessageBox.Show("Filmi eklemek istediğinize emin misiniz ?", "Film Silme", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (sonuc == DialogResult.Yes)
                { 
                    var filmTurID = ((FilmTur)cmbTur.SelectedItem).filmTurID;
                    Film f = new Film();
                    f.ad = txtAd.Text;
                    f.sure = Convert.ToDouble(txtSure.Text);
                    f.konu = txtKonu.Text;
                    f.puan = Convert.ToDouble(txtPuan.Text);
                    f.oyuncu = txtOyuncu.Text;
                    f.filmTurId = filmTurID;
                    f.afis = txtAfis.Text;
                    f.cikisTarihi = Convert.ToInt16(nupCikisTarihi.Value);
                    f.aciklama = rchtxtAciklama.Text;
                    f.filmDosyaYolu = txtFilmDosyaYolu.Text;

                    var films = db.Film.ToList(); // Film CopyRight
                    foreach (var film in films)
                    {
                        if (f.ad == film.ad)
                        {
                            MessageBox.Show("Bu isimde film bulunmakta. Lütfen tekrar deneyiniz.", "Uyarı!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            TemizleFilm();
                            ListeleFilm();
                            return;
                        }
                    }
                    
                    db.Film.Add(f);
                    db.SaveChanges();


                    MessageBox.Show(f.ad + " Ad'lı Film başarılı bir şekilde kaydolmuştur.", "Film Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Film ekleme işlemi iptal edildi.", "Ekleme İptal!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                TemizleFilm();

                ListeleFilm();
            }
        }
        private void btnFilmGuncelle_Click(object sender, EventArgs e)
        {
            adminControl = true;
            adminControls();
            

            if (adminControl)
            {
                DialogResult sonuc = MessageBox.Show("Değişiklikler kaydedilsin mi?", "Film Güncelleme", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (sonuc == DialogResult.Yes)
                {
                    int filmID = (int)gridFilm.SelectedRows[0].Cells[0].Value;
                    var filmTurID = ((FilmTur)cmbTur.SelectedItem).filmTurID;


                    Film f = db.Film.Where(x => x.FilmID == filmID).SingleOrDefault();


                    f.ad = txtAd.Text;
                    f.sure = Convert.ToDouble(txtSure.Text);
                    f.konu = txtKonu.Text;
                    f.puan = Convert.ToDouble(txtPuan.Text);
                    f.oyuncu = txtOyuncu.Text;
                    f.filmTurId = filmTurID;
                    f.afis = txtAfis.Text;
                    f.cikisTarihi = Convert.ToInt16(nupCikisTarihi.Value);
                    f.aciklama = rchtxtAciklama.Text;
                    f.filmDosyaYolu = txtFilmDosyaYolu.Text;
                    // Film CopyRight
                    db.SaveChanges();
                    ListeleFilm();
                    TemizleFilm();
                    MessageBox.Show("Başarıyla Güncellendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Değişiklikler iptal edildi.", "Film Güncelleme", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnFilmDosyasıEkle_Click(object sender, EventArgs e)
        {
            fileDialogFilm.ShowDialog();            
            txtFilmDosyaYolu.Text = fileDialogFilm.FileName;

        }
        private void gridFilm_CellClick(object sender, DataGridViewCellEventArgs e)
        { // Listeden seçilen film bilgilerinin ilgili toollara eklenmesi.
            bool secimOnaylandi = false;
            for (int i = 0; i < gridFilm.SelectedRows[0].Cells.Count; i++)
            {
                var filmSatiri = gridFilm.SelectedRows[0].Cells[i].Value;
                if (filmSatiri != null)
                {
                    secimOnaylandi = true;
                }

                else if (filmSatiri == null)
                {
                    secimOnaylandi = false;
                }
                    

                else if (filmSatiri.ToString() != "")
                    secimOnaylandi = true;

                else if (Convert.ToInt32(filmSatiri) != 0)
                    secimOnaylandi = true;

                else
                    secimOnaylandi = false;

                
            }
            if (secimOnaylandi)
            {
                txtAd.Text = gridFilm.SelectedRows[0].Cells[1].Value.ToString();
                txtSure.Text = gridFilm.SelectedRows[0].Cells[2].Value.ToString();
                txtKonu.Text = gridFilm.SelectedRows[0].Cells[3].Value.ToString();
                txtPuan.Text = gridFilm.SelectedRows[0].Cells[4].Value.ToString();
                txtOyuncu.Text = gridFilm.SelectedRows[0].Cells[5].Value.ToString();
                cmbTur.Text = gridFilm.SelectedRows[0].Cells[6].Value.ToString();
                txtAfis.Text = gridFilm.SelectedRows[0].Cells[7].Value.ToString();
                pctrAfis.ImageLocation = txtAfis.Text;
                nupCikisTarihi.Value = Convert.ToDecimal(gridFilm.SelectedRows[0].Cells[8].Value);
                rchtxtAciklama.Text = gridFilm.SelectedRows[0].Cells[9].Value.ToString();
                txtFilmDosyaYolu.Text = gridFilm.SelectedRows[0].Cells[10].Value.ToString();
            }
            else
                MessageBox.Show("Film bilgileri eksik. Lütfen admine başvurun!","Bilgiler Eksik!",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            
        }
        private void lblGörüntüle_Click(object sender, EventArgs e)
        {
            ListeleFilm();
            lblGörüntüle.Visible = false;
            txtFilmAra.Text = "Film Ara...";
        }
        private void txtFilmAra_Click(object sender, EventArgs e)
        {
            txtFilmAra.Text = "";
        }
        private void pcrCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion

        #region Key Events
        private void txtPuan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && (sender as TextBox).Text.IndexOf(',') > -1)
            {
                e.Handled = true;
            }
        }

        private void txtSure_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && (sender as TextBox).Text.IndexOf(',') > -1)
            {
                e.Handled = true;
            }
        }        

        private void txtFilmAra_KeyDown(object sender, KeyEventArgs e)
        {
            arama = txtFilmAra.Text;
            if (e.KeyCode == Keys.Enter)
            {
                var film = db.Film.Where(x => x.ad == arama).ToList();
                if (film.Count == 0)
                {
                    MessageBox.Show("Aradığınız isimde bir film bulunmamaktadır. Lütfen tekrar deneyiniz.", "Hata!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);                   
                }
                else
                {
                    gridFilm.DataSource = db.Film.Where(x=> x.ad == arama).Select(x =>
                new
                {

                    x.FilmID,
                    x.ad,
                    x.sure,
                    x.konu,
                    x.puan,
                    x.oyuncu,
                    tur = x.FilmTur.ad,
                    x.afis,
                    x.cikisTarihi,
                    x.aciklama,
                    x.filmDosyaYolu

                }).ToList();
                    lblGörüntüle.Visible = true;                    
                }
            }
        }

        private void pcrBack_Click(object sender, EventArgs e)
        {
            frmAnasayfa frm = new frmAnasayfa();
            this.Hide();
            frm.Show();
        }
        #endregion

        //-------------------------ÇÖP KUTUSU ALANI! PROJENİN GEÇMİŞ METHODLARINI İÇERİR! DEVELOPER İZNİ OLMADAN DEĞİŞTİRMEYİN LÜTFEN (ByCrystal02)-------------------------\\
    }
}
