﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25102022_Capella_MaskeliBeşler
{
    public partial class frmMediaPlayer : Form
    {
        public frmMediaPlayer()
        {
            InitializeComponent();
        }

        #region Form Load
        private void frmMediaPlayer_Load(object sender, EventArgs e)
        {
            pcrBack.Visible = true;          
        }
        #endregion

        #region Key Events
        bool tikladimi = true;
        private void wmpFilm_KeyPressEvent(object sender, AxWMPLib._WMPOCXEvents_KeyPressEvent e)
        {
            if (e.nKeyAscii == 102 || e.nKeyAscii == 70) // F tuşuna basma durumunda yaşanacak işlem.
            {
                
                if (tikladimi == true)
                {
                    this.WindowState = FormWindowState.Normal;
                    this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
                    lblNasilKullanilir.Visible = true;
                    pcrBack.Visible = true;
                    tikladimi = false;
                }
                else if (tikladimi == false)
                {                    
                    this.WindowState = FormWindowState.Maximized;
                    this.FormBorderStyle = FormBorderStyle.None;
                    lblNasilKullanilir.Visible = false;
                    pcrBack.Visible = false;                    
                    tikladimi = true;
                }
            }
        }
        #endregion

        #region Click Events        
        private void lblNasilKullanilir_Click(object sender, EventArgs e)
        {
            frmInformation frm = new frmInformation();
            frm.ShowDialog();
        }
        private void pcrBack_Click(object sender, EventArgs e)
        {
            frmAnasayfa frm = new frmAnasayfa();
            wmpFilm.close();
            this.Hide();
            frm.Show();
        }
        #endregion

        #region Form Closed/Closing
        private void frmMediaPlayer_FormClosed(object sender, FormClosedEventArgs e)
        {  
            Application.Exit();
        }
        #endregion


        //-------------------------ÇÖP KUTUSU ALANI! PROJENİN GEÇMİŞ METHODLARINI İÇERİR! DEVELOPER İZNİ OLMADAN DEĞİŞTİRMEYİN LÜTFEN (ByCrystal02)-------------------------\\
        private void frmMediaPlayer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'f' || e.KeyChar == 'F')
            {

                if (tikladimi == true)
                {
                    this.WindowState = FormWindowState.Normal;
                    tikladimi = false;
                }
                else if (tikladimi == false)
                {
                    this.WindowState = FormWindowState.Maximized;
                    tikladimi = true;
                }
            }
        }

    }
}
